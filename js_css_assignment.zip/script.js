// Function to store user preference (for example, theme color)
function saveUserPreference() {
  const userColor = document.getElementById("colorPicker").value;
  localStorage.setItem("themeColor", userColor);
  document.body.style.backgroundColor = userColor; // Apply the saved color
}

// Function to retrieve user preference and apply it
function loadUserPreference() {
  const savedColor = localStorage.getItem("themeColor");
  if (savedColor) {
    document.body.style.backgroundColor = savedColor; // Apply the saved color
  }
}

// Event listener to apply color when user selects a new one
document.getElementById("colorPicker").addEventListener("input", saveUserPreference);

// Trigger animation on button click
document.getElementById("animateBtn").addEventListener("click", function () {
  const element = document.getElementById("animateDiv");
  element.classList.add("fade-in");
});

// Load user preferences when page is loaded
window.onload = loadUserPreference;