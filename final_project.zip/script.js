
function changeText() {
    alert("Thanks for clicking the button!");
}
